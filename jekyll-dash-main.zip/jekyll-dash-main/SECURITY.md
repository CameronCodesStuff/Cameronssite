# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x   | :white_check_mark: |
| 2.x   | :white_check_mark: |

## Reporting a Vulnerability

Report any vulnerability [as an issue here](https://github.com/bitbrain/jekyll-dash/issues).
